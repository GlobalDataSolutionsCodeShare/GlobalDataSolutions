﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Text;
using UniversalSurgicals.BusinessEntities;

namespace UniversalWebsite
{
    public partial class RequestService : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            
        }

        protected void btsubmit_Click(object sender, EventArgs e)
        {

     

            Emails objEmail = new Emails();
            StringBuilder sb = new StringBuilder();
            sb.Append("<html xmlns=\"http://www.w3.org/1999/xhtml\"><head><meta http-equiv=\"Content-Type\" content=\"text/html; charset=utf-8\" /><title>Universal Surgicals</title></head><body style=\"background-color:#e7e8ea;\"> <div style=\"max-width:800px; width:100%; margin:0px auto;\"><table width=\"100%\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\"><tr bgcolor=\"#333645\" style=\"padding: 30px;\"><td height=\"150px;\" style=\"padding-left:30px;\"> <img src=\"http://usexpense.globaldatasolutions.com/Content/Images/login-logo.png\"></td></tr><tr bgcolor=\"#FFFFFF\"><td  style=\"font-family:'Open Sans';padding:40px;\"><div style=\"width:100%; font-size:18px; font-weight: bold; font-weight:800px; color:#3dbeba;\">Dear Admin,</div><br/><br/>We received new order/service request. Following are the details;<br/><div style=\"border-radius: 5px; border:  solid 1px #e7e8ea; padding:20px;  font-size:14px;  font-weight: bold; color:#868686; margin-top:20px;\"><table width=\"100%\"><tr><td style=\"font-size:13px;  font-weight: normal; color:#868686;\"><b> Name:-&nbsp;&nbsp;</b>" + txtname.Text + "</td></tr><tr><td style=\"font-size:13px;  font-weight: normal; color:#868686;\"><b>Email:-&nbsp;&nbsp;</b>" + txtemail.Text + "</td></tr>"
                + "<tr><td style=\"font-size:13px;  font-weight: normal; color:#868686;\"><b>Order For:-&nbsp;&nbsp;</b>" + ddlproduct.SelectedItem.ToString() + "</td></tr>"
                + "<tr><td style=\"font-size:13px;  font-weight: normal; color:#868686;\"><b>Order Required before:-&nbsp;&nbsp;</b>" + txtdate.Text + "</td></tr>"
                + "<tr><td style=\"font-size:13px;  font-weight: normal; color:#868686;\"><b>Company:-&nbsp;&nbsp;</b>" + txtcompany.Text + "</td></tr>"
                + "<tr><td style=\"font-size:13px;  font-weight: normal; color:#868686;\"><b>Mobile:-&nbsp;&nbsp;</b>" + txtmobile.Text + "</td></tr>"
                + "<tr><td style=\"font-size:13px;  font-weight: normal; color:#868686;\"><b>Message:-&nbsp;&nbsp;</b>" + txtmessage.Text + "</td></tr>"
                + "</table></div>");
            sb.Append("<div style=\"color:#868686; font-size:13px; margin-top:15px; color:#3dbeba; float: right;  font-weight: 700; text-align: center;\"><b>Thank You,</b><br/><b>Team Universal Surgicals</b></div>");
            sb.Append("</td></tr></table></div></body></html>");
            //objEmail.GDSSendBulkeMail(txtemail.Text.Trim(), System.Configuration.ConfigurationManager.AppSettings["webmail"].ToString(), "", "", sb.ToString(), "Received new order/service request !!", "", "Iwjil");

            objEmail.GDSSendBulkeMail(System.Configuration.ConfigurationManager.AppSettings["webmail"].ToString(), "orders@universalsurgicals.in", "", "", sb.ToString(), "Received new order/service request !!", "", "Iwjil");

            //objEmail.GDSSendBulkeMail(txtemail.Text.Trim(), System.Configuration.ConfigurationManager.AppSettings["webmail"].ToString(), "", "", sb.ToString(), "Received new order/service request !!", "", "Iwjil");

            StringBuilder sb1 = new StringBuilder();
            sb1.Append("<html xmlns=\"http://www.w3.org/1999/xhtml\"><head><meta http-equiv=\"Content-Type\" content=\"text/html; charset=utf-8\" /><title>Universal Surgicals</title></head><body style=\"background-color:#e7e8ea;\"> <div style=\"max-width:800px; width:100%; margin:0px auto;\"><table width=\"100%\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\"><tr bgcolor=\"#333645\" style=\"padding: 30px;\"><td height=\"150px;\" style=\"padding-left:30px;\"> <img src=\"http://usexpense.globaldatasolutions.com/Content/Images/login-logo.png\"></td></tr><tr bgcolor=\"#FFFFFF\"><td  style=\"font-family:'Open Sans';padding:40px;\"><div style=\"width:100%; font-size:18px; font-weight: bold; font-weight:800px; color:#3dbeba;\">Dear " + txtname.Text + "</div><div style=\"border-radius: 5px; border:  solid 1px #e7e8ea; padding:20px;  font-size:14px;  font-weight: bold; color:#868686; margin-top:20px;\"><table width=\"100%\"><tr><td style=\"font-size:13px;  font-weight: normal; color:#868686;\"> <b>Thank you! Your request has been placed successfully !!</b> </td> </tr></table></div>");
            sb1.Append("<div style=\"color:#868686; font-size:13px; margin-top:15px;\">Thank you for choosing Universal Surgicals for your business needs, your request has been placed successfully, one of our representative will contact you soon.<br/></div>");
            sb1.Append("<div style=\"color:#868686; font-size:13px; margin-top:15px; color:#3dbeba; float: right;  font-weight: 700; text-align: center;\"><b>Thank You,</b><br/><b>Team Universal Surgicals</b></div>");
            sb1.Append("</td></tr></table></div></body></html>");
            objEmail.GDSSendBulkeMail(System.Configuration.ConfigurationManager.AppSettings["webmail"].ToString(), txtemail.Text.Trim(), "", "", sb1.ToString(), "Your request has been placed successfully !!", "", "Iwjil");



            
            lblresult.InnerText = "Your Request submitted successfully";


            txtcompany.Text="";
            txtdate.Text = "";
            txtemail.Text = "";
            txtmessage.Text = "";
            txtmobile.Text = "";
            txtname.Text = "";
            ddlproduct.SelectedIndex = 0;

        }
    }
}