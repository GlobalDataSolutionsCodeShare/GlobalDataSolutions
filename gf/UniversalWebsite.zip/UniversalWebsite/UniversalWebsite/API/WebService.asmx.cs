﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Services;
using System.Data;
using System.Globalization;
using System.Web.Script.Serialization;
using System.Text;
using System.Net.Mail;
using UniversalSurgicals.BusinessEntities;
using Newtonsoft.Json;
using System.Reflection;
using System.Data;
using System.Data.SqlClient;
using System.IO;
using System.Configuration;



namespace UniversalWebsite.API
{
    /// <summary>
    /// Summary description for WebService
    /// </summary>
    [WebService(Namespace = "http://tempuri.org/")]
    [WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
    [System.ComponentModel.ToolboxItem(false)]
    // To allow this Web Service to be called from script, using ASP.NET AJAX, uncomment the following line. 
    [System.Web.Script.Services.ScriptService]
    public class WebService : System.Web.Services.WebService
    {

        [WebMethod]
        public string HelloWorld()
        {
            return "Hello World";
        }


        [WebMethod]
        public List<UniversalWebsite.ServiceReference.Jobs> GetJobs()
        {
            List<UniversalWebsite.ServiceReference.Jobs> listjobs = new List<UniversalWebsite.ServiceReference.Jobs>();
            ServiceReference.UniversalApiSoapClient objjobs = new ServiceReference.UniversalApiSoapClient();
            listjobs = objjobs.GetJobs().ToList();
            return listjobs.Where(x => x.IsActive == true).ToList();
        }

        [WebMethod]
        public List<UniversalWebsite.ServiceReference.Events> GetEvents()
        {
            List<UniversalWebsite.ServiceReference.Events> listEvents = new List<UniversalWebsite.ServiceReference.Events>();
            ServiceReference.UniversalApiSoapClient objjobs = new ServiceReference.UniversalApiSoapClient();
            listEvents = objjobs.GetEvents().ToList();
            return listEvents.Where(x => x.Status == true).ToList();
        }

        [WebMethod]
        public UniversalWebsite.ServiceReference.Events GetEventById()
        {
            string url = HttpContext.Current.Request.Url.Query;
            int a = url.IndexOf("=") + 1;
            int b = url.Length;
            string id = url.Substring(a, b - a);
            UniversalWebsite.ServiceReference.Events events = new ServiceReference.Events();
            ServiceReference.UniversalApiSoapClient objjobs = new ServiceReference.UniversalApiSoapClient();
            events = objjobs.GetEventById(int.Parse(id));
            return events;
        }

        [WebMethod]

        public bool ContactUs(string name, string email, string mobile, string company, string message)
        {

            Emails objEmail1 = new Emails();
            ContactUs contactus = new ContactUs();

            contactus.Name = name;

            contactus.Email = email;

            contactus.Mobile = mobile;

            contactus.Company = company;

            contactus.Message = message;


            StringBuilder sb1 = new StringBuilder();
            sb1.Append("<html xmlns=\"http://www.w3.org/1999/xhtml\"><head><meta http-equiv=\"Content-Type\" content=\"text/html; charset=utf-8\" /><title>Universal Surgicals</title></head><body style=\"background-color:#e7e8ea;\"> <div style=\"max-width:800px; width:100%; margin:0px auto;\"><table width=\"100%\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\"><tr bgcolor=\"#333645\" style=\"padding: 30px;\"><td height=\"150px;\" style=\"padding-left:30px;\"> <img src=\"http://usexpense.globaldatasolutions.com/Content/Images/login-logo.png\"></td></tr><tr bgcolor=\"#FFFFFF\"><td  style=\"font-family:'Open Sans';padding:40px;\"><div style=\"width:100%; font-size:18px; font-weight: bold; font-weight:800px; color:#3dbeba;\">Dear Admin,</div><br/><br/>We received new order/service request. Following are the details;<br/><div style=\"border-radius: 5px; border:  solid 1px #e7e8ea; padding:20px;  font-size:14px;  font-weight: bold; color:#868686; margin-top:20px;\"><table width=\"100%\"><tr><td style=\"font-size:13px;  font-weight: normal; color:#868686;\"<b>Name:- </b>" + name + "</td><br/><br/><td style=\"font-size:13px;  font-weight: normal; color:#868686;\"><b> Email:- </b>" + email + "</td><br/>"
                //+ "<td style=\"font-size:13px;  font-weight: normal; color:#868686;\">Order For:- " + product1 + "</td><br/>"
                  + "<td style=\"font-size:13px;  font-weight: normal; color:#868686;\"><b>Company:- </b> " + company + "</td><br/>"
                  + "<td style=\"font-size:13px;  font-weight: normal; color:#868686;\"><b>Mobile:- </b> " + mobile + "</td><br/>"
                  + "<td style=\"font-size:13px;  font-weight: normal; color:#868686;\"><b>Message:- </b> " + message + "</td><br/>"
                  + "<td style=\"font-size:13px;  font-weight: normal; color:#868686;\"> <b>Thank you for your valuable Feedback !!</b> </td> </tr></table></div>");
            sb1.Append("<div style=\"color:#868686; font-size:13px; margin-top:15px;\">We appreciate you taking the time to providing us your feedback. Please allow us some time to investigate your concern. Rest assured that our representative will get back to you.<br/></div>");
            sb1.Append("<div style=\"color:#868686; font-size:13px; margin-top:15px; color:#3dbeba; float: right;  font-weight: 700; text-align: center;\"><b>Thank You,</b><br/><b>Team Universal Surgicals</b></div>");
            sb1.Append("</td></tr></table></div></body></html>");

            objEmail1.GDSSendBulkeMail(email, System.Configuration.ConfigurationManager.AppSettings["webmail"].ToString(), "", "", sb1.ToString(), " Received new contact Request !", "", "Iwjil");

            StringBuilder sb = new StringBuilder();
            sb.Append("<html xmlns=\"http://www.w3.org/1999/xhtml\"><head><meta http-equiv=\"Content-Type\" content=\"text/html; charset=utf-8\" /><title>Universal Surgicals</title></head><body style=\"background-color:#e7e8ea;\"> <div style=\"max-width:800px; width:100%; margin:0px auto;\"><table width=\"100%\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\"><tr bgcolor=\"#333645\" style=\"padding: 30px;\"><td height=\"150px;\" style=\"padding-left:30px;\"> <img src=\"http://usexpense.globaldatasolutions.com/Content/Images/login-logo.png\"></td></tr><tr bgcolor=\"#FFFFFF\"><td  style=\"font-family:'Open Sans';padding:40px;\"><div style=\"width:100%; font-size:18px; font-weight: bold; font-weight:800px; color:#3dbeba;\">Dear " + name + "</div><div style=\"border-radius: 5px; border:  solid 1px #e7e8ea; padding:20px;  font-size:14px;  font-weight: bold; color:#868686; margin-top:20px;\"><table width=\"100%\"><tr><td style=\"font-size:13px;  font-weight: normal; color:#868686;\"> <b>Your request has been placed successfully !!.</b> </td> </tr></table></div>");
            sb.Append("<div style=\"color:#868686; font-size:13px; margin-top:15px;\">Thank you for choosing Universal Surgicals for your business needs, your request has been placed successfully, one of our representative will contact you soon.<br/></div>");
            sb.Append("<div style=\"color:#868686; font-size:13px; margin-top:15px; color:#3dbeba; float: right;  font-weight: 700; text-align: center;\"><b>Thank You,</b><br/><b>Team Universal Surgicals</b></div>");
            sb.Append("</td></tr></table></div></body></html>");

            objEmail1.GDSSendBulkeMail(System.Configuration.ConfigurationManager.AppSettings["webmail"].ToString(), "info@universalsurgicals.in", "", "", sb.ToString(), "Thank You for contacting Universal Surgicals !!", "", "Iwjil");

            return true;
        }
        //[WebMethod]
        //public bool ApplyJob(string jobid, string name, string email, string mobile, string address, string availability, string pastexp, string istrainingreq, string resume)
        //{
        //    UniversalWebsite.ServiceReference.Jobs_AppliedCandidates jobs_AppliedCandidates = new ServiceReference.Jobs_AppliedCandidates();
        //    jobs_AppliedCandidates.JobId = int.Parse(jobid);
        //    jobs_AppliedCandidates.Name = name;
        //    jobs_AppliedCandidates.EmailId = email;
        //    jobs_AppliedCandidates.Phone = mobile;
        //    jobs_AppliedCandidates.Address = address;
        //    jobs_AppliedCandidates.Availability = availability;
        //    jobs_AppliedCandidates.PastExperience = pastexp;
        //    if (istrainingreq != "")
        //        jobs_AppliedCandidates.TrainingRequired = bool.Parse(istrainingreq);
        //    else
        //        jobs_AppliedCandidates.TrainingRequired = false;
        //    string newpath = jobs_AppliedCandidates.EmailId.Remove(jobs_AppliedCandidates.EmailId.IndexOf("@"), 1);
        //    newpath = newpath + jobs_AppliedCandidates.JobId + resume;
        //    jobs_AppliedCandidates.ResumeFileName = newpath;

        //    ServiceReference.UniversalApiSoapClient objService = new ServiceReference.UniversalApiSoapClient();

        //    bool result = objService.ApplyToJob(jobs_AppliedCandidates);
        //    if (result == true)
        //    {
        //        string val = "";
        //        if (jobs_AppliedCandidates.TrainingRequired == true)
        //            val = "Yes";
        //        else
        //            val = "No";


        //        Emails objEmail1 = new Emails();
        //        StringBuilder sb1 = new StringBuilder();
        //        sb1.Append("<html xmlns=\"http://www.w3.org/1999/xhtml\"><head><meta http-equiv=\"Content-Type\" content=\"text/html; charset=utf-8\" /><title>Universal Surgicals</title></head><body style=\"background-color:#e7e8ea;\"> <div style=\"max-width:800px; width:100%; margin:0px auto;\"><table width=\"100%\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\"><tr bgcolor=\"#333645\" style=\"padding: 30px;\"><td height=\"150px;\" style=\"padding-left:30px;\"> <img src=\"http://usexpense.globaldatasolutions.com/Content/Images/login-logo.png\"></td></tr><tr bgcolor=\"#FFFFFF\"><td  style=\"font-family:'Open Sans';padding:40px;\"><div style=\"width:100%; font-size:18px; font-weight: bold; font-weight:800px; color:#3dbeba;\">Dear Admin,</div><br/><br/>candidate Applied for the job " + jobid + ". Following are the Candidate details;<br/><div style=\"border-radius: 5px; border:  solid 1px #e7e8ea; padding:20px;  font-size:14px;  font-weight: bold; color:#868686; margin-top:20px;\"><table width=\"100%\"><tr><td style=\"font-size:13px;  font-weight: normal; color:#868686;\">Name:- " + name + "</td></tr><br/><br/><tr><td style=\"font-size:13px;  font-weight: normal; color:#868686;\">Email:- " + email + "</td></tr><br/>"
        //            //+ "<td style=\"font-size:13px;  font-weight: normal; color:#868686;\">Order For:- " + product1 + "</td><br/>"
        //            + "<tr><td style=\"font-size:13px;  font-weight: normal; color:#868686;\">Mobile:- " + mobile + "</td></tr><br/>"
        //            + "<tr><td style=\"font-size:13px;  font-weight: normal; color:#868686;\">Address:- " + address + "</td></tr><br/>"
        //            + "<tr><td style=\"font-size:13px;  font-weight: normal; color:#868686;\">Availability:- " + availability + "</td></tr><br/>"
        //            + "<tr><td style=\"font-size:13px;  font-weight: normal; color:#868686;\">Past Experience:- " + pastexp + "</td></tr><br/>"
        //            + "<tr><td style=\"font-size:13px;  font-weight: normal; color:#868686;\">Training Required?:- " + val + "</td></tr><br/>"
        //            + "<tr><td style=\"font-size:13px;  font-weight: normal; color:#868686;\">Availability:- " + availability + "</td></tr><br/></table></div>");
        //        sb1.Append("</td></tr></table></div></body></html>");

        //        objEmail1.GDSSendBulkeMail(email, System.Configuration.ConfigurationManager.AppSettings["webmail"].ToString(), "", "", sb1.ToString(), " Candidate Applied for the job " + jobid + " !", "", "Iwjil");

        //    }
        //    return result;
        //}


        [WebMethod(EnableSession = true)]
        public bool ApplyJobDirectly(string jobid, string name, string email, string mobile, string address, string availability, string pastexp, string istrainingreq, string resume, string Jobname)
        {
            string conn = ConfigurationManager.ConnectionStrings["ApplicationServices"].ConnectionString;
            SqlConnection con = new SqlConnection(conn);
            con.Open();

            SqlCommand com = new SqlCommand("SP_IsAlreadyApplied", con);
            com.CommandType = CommandType.StoredProcedure;
            com.Parameters.AddWithValue("@EmailId", email.Trim());
            com.Parameters.AddWithValue("@JobId", jobid);
            SqlDataAdapter da = new SqlDataAdapter(com);
            DataTable dt = new DataTable();
            da.Fill(dt);

            if (dt.Rows.Count == 0)
            {
                Jobs_AppliedCandidates jobs_AppliedCandidates = new Jobs_AppliedCandidates();
                jobs_AppliedCandidates.JobId = int.Parse(jobid);
                jobs_AppliedCandidates.Name = name;
                jobs_AppliedCandidates.EmailId = email;
                jobs_AppliedCandidates.Phone = mobile;
                jobs_AppliedCandidates.Address = address;
                jobs_AppliedCandidates.Availability = availability;
                jobs_AppliedCandidates.PastExperience = pastexp;
                if (istrainingreq != "")
                    jobs_AppliedCandidates.TrainingRequired = bool.Parse(istrainingreq);
                else
                    jobs_AppliedCandidates.TrainingRequired = false;
                string newpath = jobs_AppliedCandidates.EmailId.Remove(jobs_AppliedCandidates.EmailId.IndexOf("@"), 1);
                newpath = newpath + jobs_AppliedCandidates.JobId + resume;
                jobs_AppliedCandidates.ResumeFileName = newpath;

                Session["NewP"] = newpath;

                string sql = "INSERT INTO Jobs_AplliedCandidates VALUES (@JobId,@Name,@EmailId,@Phone,@Address,@Availability,@PastExperience,@TrainingRequired,@ResumeFileName,@CreatedDate,@UpdatedDate)";
                SqlCommand cmd = new SqlCommand(sql, con);
                cmd.Parameters.AddWithValue("@JobId", jobs_AppliedCandidates.JobId);
                cmd.Parameters.AddWithValue("@Name", jobs_AppliedCandidates.Name);
                cmd.Parameters.AddWithValue("@EmailId", jobs_AppliedCandidates.EmailId);

                cmd.Parameters.AddWithValue("@Phone", jobs_AppliedCandidates.Phone);
                cmd.Parameters.AddWithValue("@Address", jobs_AppliedCandidates.Address);

                cmd.Parameters.AddWithValue("@Availability", jobs_AppliedCandidates.Availability);
                cmd.Parameters.AddWithValue("@PastExperience", jobs_AppliedCandidates.PastExperience);
                cmd.Parameters.AddWithValue("@TrainingRequired", jobs_AppliedCandidates.TrainingRequired);
                cmd.Parameters.AddWithValue("@ResumeFileName", jobs_AppliedCandidates.ResumeFileName);
                cmd.Parameters.AddWithValue("@CreatedDate", DateTime.Now);
                cmd.Parameters.AddWithValue("@UpdatedDate", DateTime.Now);
                cmd.CommandType = CommandType.Text;
                cmd.ExecuteNonQuery();
                con.Close();


                //mail 



                return true;
            }
            else
            {
                con.Close();
                return false;
            }



        }
        [WebMethod(EnableSession = true)]
        public bool MailForApplyJob(string jobid, string name, string email, string mobile, string address, string availability, string pastexp, string istrainingreq, string resume, string Jobname)
        {
            string val = "";
            if (istrainingreq == "true")
                val = "Yes";
            else
                val = "No";
            var newpath = Session["NewP"].ToString();
            Emails objEmail1 = new Emails();
            StringBuilder sb1 = new StringBuilder();
            sb1.Append("<html xmlns=\"http://www.w3.org/1999/xhtml\"><head><meta http-equiv=\"Content-Type\" content=\"text/html; charset=utf-8\" /><title>Universal Surgicals</title></head><body style=\"background-color:#e7e8ea;\"> <div style=\"max-width:800px; width:100%; margin:0px auto;\"><table width=\"100%\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\"><tr bgcolor=\"#333645\" style=\"padding: 30px;\"><td height=\"150px;\" style=\"padding-left:30px;\"> <img src=\"http://usexpense.globaldatasolutions.com/Content/Images/login-logo.png\"></td></tr><tr bgcolor=\"#FFFFFF\"><td  style=\"font-family:'Open Sans';padding:40px;\"><div style=\"width:100%; font-size:18px; font-weight: bold; font-weight:800px; color:#3dbeba;\">Dear Admin,</div><br/>Candidate Applied for the job <b>" + HttpUtility.UrlDecode(Jobname).Trim() + "</b>. Following are the Candidate details;<br/><div style=\"border-radius: 5px; border:  solid 1px #e7e8ea; padding:20px;  font-size:14px;  font-weight: bold; color:#868686; margin-top:20px;\"><table width=\"100%\"><tr><td style=\"font-size:13px;  font-weight: normal; color:#868686;\"><b>Name:- </b>" + name + "</td></tr><br/><tr><td style=\"font-size:13px;  font-weight: normal; color:#868686;\"><b>Email:- </b>" + email + "</td></tr><br/>"
                //+ "<td style=\"font-size:13px;  font-weight: normal; color:#868686;\">Order For:- " + product1 + "</td><br/>"
                + "<tr><td style=\"font-size:13px;  font-weight: normal; color:#868686;\"><b>Mobile:- </b>" + mobile + "</td</tr><br/><br/>"
                + "<tr><td style=\"font-size:13px;  font-weight: normal; color:#868686;\"><b>Address:- </b>" + address + "</td></tr><br/>"
                + "<tr><td style=\"font-size:13px;  font-weight: normal; color:#868686;\"><b>Past Experience:- </b>" + pastexp + "</td></tr><br/>"
                + "<tr><td style=\"font-size:13px;  font-weight: normal; color:#868686;\"><b>Training Required?:- </b> " + val + "</td></tr><br/>"
                + "<tr><td style=\"font-size:13px;  font-weight: normal; color:#868686;\"><b>Availability:- </b>" + availability + "</td></tr><br/></table></div>");
            sb1.Append("</td></tr></table></div></body></html>");

            objEmail1.GDSSendBulkeMail(System.Configuration.ConfigurationManager.AppSettings["webmail"].ToString(), "sekhargandra89@gmail.com", "", "", sb1.ToString(), " Candidate Applied for the Job '" + HttpUtility.UrlDecode(Jobname).Trim() + "'!", newpath, "Iwjil");

            Session.Clear();
            Session.Remove("NewP");
            return true;
        }
        [WebMethod(EnableSession = true)]
        public bool UploadResume()
        {
            bool status = false;
            var email = HttpContext.Current.Request.Form.AllKeys[1];
            var id = HttpContext.Current.Request.Form.AllKeys[0];
            //ServiceReference.UniversalApiSoapClient obj = new ServiceReference.UniversalApiSoapClient();
            //  status=  obj.UploadResume(int.Parse(id), email);


            foreach (string file in HttpContext.Current.Request.Files)
            {

                var fileContent = HttpContext.Current.Request.Files[file];

                if (fileContent != null && fileContent.ContentLength > 0)
                {
                    var stream = fileContent.InputStream;
                    var fileName = email.Remove(email.IndexOf("@"), 1) + id + fileContent.FileName;
                    var path = Path.Combine(Server.MapPath("~/Resumes"), fileName);

                    using (var fileStream = System.IO.File.Create(path))
                    {
                        stream.CopyTo(fileStream);
                    }
                    status = true;
                }

            }
            return status;
        }

        [WebMethod]

        public bool RequestService(string name, string email, string mobile, string company, string message, string ORB, string product)
        {
            Emails objEmail = new Emails();

            ContactUs contactus = new ContactUs();

            contactus.Name = name;

            contactus.Email = email;

            contactus.Mobile = mobile;

            contactus.Company = company;

            contactus.Message = message;

            contactus.ORB = ORB;

            contactus.product = product;

            StringBuilder sb = new StringBuilder();
            sb.Append("<html xmlns=\"http://www.w3.org/1999/xhtml\"><head><meta http-equiv=\"Content-Type\" content=\"text/html; charset=utf-8\" /><title>Universal Surgicals</title></head><body style=\"background-color:#e7e8ea;\"> <div style=\"max-width:800px; width:100%; margin:0px auto;\"><table width=\"100%\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\"><tr bgcolor=\"#333645\" style=\"padding: 30px;\"><td height=\"150px;\" style=\"padding-left:30px;\"> <img src=\"http://usexpense.globaldatasolutions.com/Content/Images/login-logo.png\"></td></tr><tr bgcolor=\"#FFFFFF\"><td  style=\"font-family:'Open Sans';padding:40px;\"><div style=\"width:100%; font-size:18px; font-weight: bold; font-weight:800px; color:#3dbeba;\">Dear Admin,</div><br/><br/>We received new order/service request. Following are the details;<br/><div style=\"border-radius: 5px; border:  solid 1px #e7e8ea; padding:20px;  font-size:14px;  font-weight: bold; color:#868686; margin-top:20px;\"><table width=\"100%\"><tr><td style=\"font-size:13px;  font-weight: normal; color:#868686;\"><b>Name:-</b> " + name + "</td><br/><br/><td style=\"font-size:13px;  font-weight: normal; color:#868686;\"><b>Email:- </b>" + email + "</td><br/>"
                + "<td style=\"font-size:13px;  font-weight: normal; color:#868686;\"><b>Order For:- </b>" + product + "</td><br/>"
                + "<td style=\"font-size:13px;  font-weight: normal; color:#868686;\"><b>Company:- </b>" + company + "</td><br/>"
                + "<td style=\"font-size:13px;  font-weight: normal; color:#868686;\"><b>Mobile:-</b> " + mobile + "</td><br/>"
                + "<td style=\"font-size:13px;  font-weight: normal; color:#868686;\"><b>Message:- </b>" + message + "</td><br/>"
                + "<td style=\"font-size:13px;  font-weight: normal; color:#868686;\"> <b>Thank you for your valuable Feedback !!</b> </td> </tr></table></div>");
            sb.Append("<div style=\"color:#868686; font-size:13px; margin-top:15px;\">We appreciate you taking the time to providing us your feedback. Please allow us some time to investigate your concern. Rest assured that our representative will get back to you.<br/></div>");
            sb.Append("<div style=\"color:#868686; font-size:13px; margin-top:15px; color:#3dbeba; float: right;  font-weight: 700; text-align: center;\"><b>Thank You,</b><br/><b>Team Universal Surgicals</b></div>");
            sb.Append("</td></tr></table></div></body></html>");

            objEmail.GDSSendBulkeMail(email, System.Configuration.ConfigurationManager.AppSettings["webmail"].ToString(), "", "", sb.ToString(), "Your request has been placed successfully !!", "", "Iwjil");

            StringBuilder sb1 = new StringBuilder();

            sb1.Append("<html xmlns=\"http://www.w3.org/1999/xhtml\"><head><meta http-equiv=\"Content-Type\" content=\"text/html; charset=utf-8\" /><title>Universal Surgicals</title></head><body style=\"background-color:#e7e8ea;\"> <div style=\"max-width:800px; width:100%; margin:0px auto;\"><table width=\"100%\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\"><tr bgcolor=\"#333645\" style=\"padding: 30px;\"><td height=\"150px;\" style=\"padding-left:30px;\"> <img src=\"http://usexpense.globaldatasolutions.com/Content/Images/login-logo.png\"></td></tr><tr bgcolor=\"#FFFFFF\"><td  style=\"font-family:'Open Sans';padding:40px;\"><div style=\"width:100%; font-size:18px; font-weight: bold; font-weight:800px; color:#3dbeba;\">Dear " + name + "</div><div style=\"border-radius: 5px; border:  solid 1px #e7e8ea; padding:20px;  font-size:14px;  font-weight: bold; color:#868686; margin-top:20px;\"><table width=\"100%\"><tr><td style=\"font-size:13px;  font-weight: normal; color:#868686;\"> <b>Thank you for your valuable Feedback !!</b> </td> </tr></table></div>");
            sb.Append("<div style=\"color:#868686; font-size:13px; margin-top:15px;\">We appreciate you taking the time to providing us your feedback. Please allow us some time to investigate your concern. Rest assured that our representative will get back to you.<br/></div>");
            sb.Append("<div style=\"color:#868686; font-size:13px; margin-top:15px; color:#3dbeba; float: right;  font-weight: 700; text-align: center;\"><b>Thank You,</b><br/><b>Team Universal Surgicals</b></div>");
            sb.Append("</td></tr></table></div></body></html>");

            objEmail.GDSSendBulkeMail(System.Configuration.ConfigurationManager.AppSettings["webmail"].ToString(), "orders@universalsurgicals.in", "", "", sb1.ToString(), "Your service request submission acknowledge !!", "", "Iwjil");


            return true;
        }

        [WebMethod]
        public bool Feedback(string name, string email, string mobile, string company, string message)
        {

            Emails objEmail2 = new Emails();

            StringBuilder sb1 = new StringBuilder();
            sb1.Append("<html xmlns=\"http://www.w3.org/1999/xhtml\"><head><meta http-equiv=\"Content-Type\" content=\"text/html; charset=utf-8\" /><title>Universal Surgicals</title></head><body style=\"background-color:#e7e8ea;\"> <div style=\"max-width:800px; width:100%; margin:0px auto;\"><table width=\"100%\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\"><tr bgcolor=\"#333645\" style=\"padding: 30px;\"><td height=\"150px;\" style=\"padding-left:30px;\"> <img src=\"http://usexpense.globaldatasolutions.com/Content/Images/login-logo.png\"></td></tr><tr bgcolor=\"#FFFFFF\"><td  style=\"font-family:'Open Sans';padding:40px;\"><div style=\"width:100%; font-size:18px; font-weight: bold; font-weight:800px; color:#3dbeba;\">Dear Admin,</div><br/><br/>We received new order/service request. Following are the details;<br/><div style=\"border-radius: 5px; border:  solid 1px #e7e8ea; padding:20px;  font-size:14px;  font-weight: bold; color:#868686; margin-top:20px;\"><table width=\"100%\"><tr><td style=\"font-size:13px;  font-weight: normal; color:#868686;\"><b>Name:- </b>" + name + "</td><br/><br/><td style=\"font-size:13px;  font-weight: normal; color:#868686;\"><b>Email:- </b>" + email + "</td><br/>"
                //+ "<td style=\"font-size:13px;  font-weight: normal; color:#868686;\">Order For:- " + product + "</td><br/>"
                + "<td style=\"font-size:13px;  font-weight: normal; color:#868686;\"><b>Company:- </b>" + company + "</td><br/>"
                + "<td style=\"font-size:13px;  font-weight: normal; color:#868686;\"><b>Mobile:- </b>" + mobile + "</td><br/>"
                + "<td style=\"font-size:13px;  font-weight: normal; color:#868686;\"><b>Message:- </b>" + message + "</td><br/>"
                + "<td style=\"font-size:13px;  font-weight: normal; color:#868686;\"> <b>Thank you for your valuable Feedback !!</b> </td> </tr></table></div>");
            sb1.Append("<div style=\"color:#868686; font-size:13px; margin-top:15px;\">We appreciate you taking the time to providing us your feedback. Please allow us some time to investigate your concern. Rest assured that our representative will get back to you.<br/></div>");
            sb1.Append("<div style=\"color:#868686; font-size:13px; margin-top:15px; color:#3dbeba; float: right;  font-weight: 700; text-align: center;\"><b>Thank You,</b><br/><b>Team Universal Surgicals</b></div>");
            sb1.Append("</td></tr></table></div></body></html>");

            objEmail2.GDSSendBulkeMail(email, System.Configuration.ConfigurationManager.AppSettings["webmail"].ToString(), "", "", sb1.ToString(), "Received new Feedback  !!", "", "Iwjil");


            StringBuilder sb = new StringBuilder();
            sb.Append("<html xmlns=\"http://www.w3.org/1999/xhtml\"><head><meta http-equiv=\"Content-Type\" content=\"text/html; charset=utf-8\" /><title>Universal Surgicals</title></head><body style=\"background-color:#e7e8ea;\"> <div style=\"max-width:800px; width:100%; margin:0px auto;\"><table width=\"100%\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\"><tr bgcolor=\"#333645\" style=\"padding: 30px;\"><td height=\"150px;\" style=\"padding-left:30px;\"> <img src=\"http://usexpense.globaldatasolutions.com/Content/Images/login-logo.png\"></td></tr><tr bgcolor=\"#FFFFFF\"><td  style=\"font-family:'Open Sans';padding:40px;\"><div style=\"width:100%; font-size:18px; font-weight: bold; font-weight:800px; color:#3dbeba;\">Dear " + name + "</div><div style=\"border-radius: 5px; border:  solid 1px #e7e8ea; padding:20px;  font-size:14px;  font-weight: bold; color:#868686; margin-top:20px;\"><table width=\"100%\"><tr><td style=\"font-size:13px;  font-weight: normal; color:#868686;\"> <b>Thank you for your valuable Feedback !!</b> </td> </tr></table></div>");
            sb.Append("<div style=\"color:#868686; font-size:13px; margin-top:15px;\">We appreciate you taking the time to providing us your feedback. Please allow us some time to investigate your concern. Rest assured that our representative will get back to you.<br/></div>");
            sb.Append("<div style=\"color:#868686; font-size:13px; margin-top:15px; color:#3dbeba; float: right;  font-weight: 700; text-align: center;\"><b>Thank You,</b><br/><b>Team Universal Surgicals</b></div>");
            sb.Append("</td></tr></table></div></body></html>");

            objEmail2.GDSSendBulkeMail(System.Configuration.ConfigurationManager.AppSettings["webmail"].ToString(), "info@universalsurgicals.in", "", "", sb.ToString(), "Thank you for your valuable Feedback !!", "", "Iwjil");



            return true;
        }


    }
}