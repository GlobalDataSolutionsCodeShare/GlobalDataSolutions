﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using UniversalSurgicals.BusinessEntities;
using System.Text;

namespace UniversalWebsite
{
    public partial class feedback : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btsubmitf_Click(object sender, EventArgs e)
        {



            Emails objEmail2 = new Emails();

            Emails objEmail = new Emails();
            StringBuilder sb1 = new StringBuilder();
            sb1.Append("<html xmlns=\"http://www.w3.org/1999/xhtml\"><head><meta http-equiv=\"Content-Type\" content=\"text/html; charset=utf-8\" /><title>Universal Surgicals</title></head><body style=\"background-color:#e7e8ea;\"> <div style=\"max-width:800px; width:100%; margin:0px auto;\"><table width=\"100%\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\"><tr bgcolor=\"#333645\" style=\"padding: 30px;\"><td height=\"150px;\" style=\"padding-left:30px;\"> <img src=\"http://usexpense.globaldatasolutions.com/Content/Images/login-logo.png\"></td></tr><tr bgcolor=\"#FFFFFF\"><td  style=\"font-family:'Open Sans';padding:40px;\"><div style=\"width:100%; font-size:18px; font-weight: bold; font-weight:800px; color:#3dbeba;\">Dear Admin,</div><br/><br/>We received new Feedback, Following are the details; <br/><div style=\"border-radius: 5px; border:  solid 1px #e7e8ea; padding:20px;  font-size:14px;  font-weight: bold; color:#868686; margin-top:20px;\"><table width=\"100%\"><tr><td style=\"font-size:13px;  font-weight: normal; color:#868686;\"><b> Name:-&nbsp;&nbsp;</b>" + txtfname.Text + "</td></tr><tr><td style=\"font-size:13px;  font-weight: normal; color:#868686;\"><b>Email:-&nbsp;&nbsp;</b>" + txtfemail.Text + "</td></tr>"
                + "<tr><td style=\"font-size:13px;  font-weight: normal; color:#868686;\"><b>Company:-&nbsp;&nbsp;</b>" + txtfcompany.Text + "</td></tr>"
                + "<tr><td style=\"font-size:13px;  font-weight: normal; color:#868686;\"><b>Mobile:-&nbsp;&nbsp;</b>" + txtfmobile.Text + "</td></tr>"
                + "<tr><td style=\"font-size:13px;  font-weight: normal; color:#868686;\"><b>Message:-&nbsp;&nbsp;</b>" + txtfmessage.Text + "</td></tr>"
                + "</table></div>");
            sb1.Append("<div style=\"color:#868686; font-size:13px; margin-top:15px; color:#3dbeba; float: right;  font-weight: 700; text-align: center;\"><b>Thank You,</b><br/><b>Team Universal Surgicals</b></div>");
            sb1.Append("</td></tr></table></div></body></html>");
            objEmail.GDSSendBulkeMail(System.Configuration.ConfigurationManager.AppSettings["webmail"].ToString(), "info@universalsurgicals.in", "", "", sb1.ToString(), "Received new Feedback  !!", "", "Iwjil");


            StringBuilder sb = new StringBuilder();
            sb.Append("<html xmlns=\"http://www.w3.org/1999/xhtml\"><head><meta http-equiv=\"Content-Type\" content=\"text/html; charset=utf-8\" /><title>Universal Surgicals</title></head><body style=\"background-color:#e7e8ea;\"> <div style=\"max-width:800px; width:100%; margin:0px auto;\"><table width=\"100%\" border=\"0\" cellspacing=\"0\" cellpadding=\"0\"><tr bgcolor=\"#333645\" style=\"padding: 30px;\"><td height=\"150px;\" style=\"padding-left:30px;\"> <img src=\"http://usexpense.globaldatasolutions.com/Content/Images/login-logo.png\"></td></tr><tr bgcolor=\"#FFFFFF\"><td  style=\"font-family:'Open Sans';padding:40px;\"><div style=\"width:100%; font-size:18px; font-weight: bold; font-weight:800px; color:#3dbeba;\">Dear " + txtfname.Text + "</div><div style=\"border-radius: 5px; border:  solid 1px #e7e8ea; padding:20px;  font-size:14px;  font-weight: bold; color:#868686; margin-top:20px;\"><table width=\"100%\"><tr><td style=\"font-size:13px;  font-weight: normal; color:#868686;\"> <b>Thank you for your valuable Feedback !!</b> </td> </tr></table></div>");
            sb.Append("<div style=\"color:#868686; font-size:13px; margin-top:15px;\">We appreciate you taking the time to providing us your feedback. Please allow us some time to investigate your concern. Rest assured that our representative will get back to you.<br/></div>");
            sb.Append("<div style=\"color:#868686; font-size:13px; margin-top:15px; color:#3dbeba; float: right;  font-weight: 700; text-align: center;\"><b>Thank You,</b><br/><b>Team Universal Surgicals</b></div>");
            sb.Append("</td></tr></table></div></body></html>");

            objEmail2.GDSSendBulkeMail(System.Configuration.ConfigurationManager.AppSettings["webmail"].ToString(), txtfemail.Text.Trim(), "", "", sb.ToString(), "Thank you for your valuable Feedback !!", "", "Iwjil");

            lblresult.InnerText = "Thank you for your valuable feedback";

            txtfcompany.Text = "";
            txtfemail.Text = "";
            txtfmessage.Text = "";
            txtfmobile.Text = "";
            txtfname.Text = "";
           

        }
    }
}