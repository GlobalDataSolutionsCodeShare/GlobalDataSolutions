﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace UniversalSurgicals.BusinessEntities
{
    public class ContactUs
    {

        public string Name {set;get; }
         
        public string Email { set; get; }

        public string Mobile { set; get; }

        public string Company { set; get; }

        public string Message { set; get; }

        public string ORB { set; get; }

        public string product { set; get; }
    }
}
