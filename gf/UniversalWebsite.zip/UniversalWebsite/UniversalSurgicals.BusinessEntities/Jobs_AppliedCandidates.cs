﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace UniversalSurgicals.BusinessEntities
{
    public class Jobs_AppliedCandidates 
    {
     
        public int? Id { get; set; }

       
        public int? JobId { get; set; }

      
        public string Name { get; set; }

       
         public string EmailId { get; set; }

       
     
        public string Phone { get; set; }

      
      
        public string Address { get; set; }

       
        //[Required(ErrorMessage = "Please Select Availability")]
        public string Availability { get; set; }

       
        public string PastExperience { get; set; }

        public bool TrainingRequired { get; set; }

       
        public string ResumeFileName { get; set; }

   
        public DateTime? CreatedDate { get; set; }

       
        public DateTime? ModifiedDate { get; set; }
    }
}
